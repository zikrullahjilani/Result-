from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
import logging
import subprocess
import shutil
import requests
import functools
from typing import Callable
from pathlib import Path

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def retry_on_exception(retries: int = 3, delay: int = 2) -> Callable:
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if attempt == retries - 1:  # Last attempt
                        logging.error(f"Failed after {retries} attempts: {str(e)}")
                        raise
                    logging.warning(f"Attempt {attempt + 1} failed: {str(e)}")
                    time.sleep(delay * (attempt + 1))  # Exponential backoff
            return None
        return wrapper
    return decorator

def upload_to_telegram(file_path: str, caption: str = "") -> bool:
    """Upload a file to Telegram channel."""
    try:
        bot_token = os.environ.get('TELEGRAM_BOT_TOKEN')
        channel_id = os.environ.get('TELEGRAM_CHANNEL_ID')

        if not bot_token or not channel_id:
            logging.error("Telegram credentials not found")
            return False

        url = f"https://api.telegram.org/bot{bot_token}/sendDocument"

        with open(file_path, 'rb') as file:
            files = {'document': file}
            data = {'chat_id': channel_id, 'caption': caption}

            response = requests.post(url, data=data, files=files)

            if response.status_code == 200:
                logging.info(f"Successfully uploaded {file_path} to Telegram")
                return True
            else:
                logging.error(f"Failed to upload {file_path}. Status code: {response.status_code}")
                return False
    except Exception as e:
        logging.error(f"Error uploading to Telegram: {str(e)}")
        return False

def cleanup_file(file_path: str) -> None:
    """Delete a file if it exists."""
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
            logging.info(f"Successfully deleted {file_path}")
    except Exception as e:
        logging.error(f"Error deleting file {file_path}: {str(e)}")

def get_full_height(driver):
    return driver.execute_script("""
        return Math.max(
            document.body.scrollHeight, document.documentElement.scrollHeight,
            document.body.offsetHeight, document.documentElement.offsetHeight,
            document.body.clientHeight, document.documentElement.clientHeight
        );
    """)

def get_student_name(driver) -> str:
    """Extract student name from the result page."""
    try:
        # First try to find any table cell containing 'Name'
        name_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//td[contains(text(), 'Name')]")))
        logging.info(f"Found name element: {name_element.text}")
        return name_element.text.split(':')[-1].strip()
    except:
        try:
            # Fallback: Try to find first row of the result table
            table = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.TAG_NAME, "table")))
            rows = table.find_elements(By.TAG_NAME, "tr")
            for row in rows:
                cells = row.find_elements(By.TAG_NAME, "td")
                for cell in cells:
                    if "Name" in cell.text:
                        logging.info(f"Found name in table cell: {cell.text}")
                        return cell.text.split(':')[-1].strip()
        except:
            try:
                # Last resort: Try finding any element containing 'Name' using JavaScript
                script = """
                    return Array.from(document.getElementsByTagName('td')).find(
                        td => td.textContent.includes('Name')
                    )?.textContent || '';
                """
                result = driver.execute_script(script)
                if result:
                    logging.info(f"Found name using JavaScript: {result}")
                    return result.split(':')[-1].strip()
            except:
                logging.warning("Could not extract student name")
                logging.error(f"Page source at error:\n{driver.page_source}")
                return ""
    return ""

@retry_on_exception(retries=3, delay=2)
def setup_driver():
    try:
        chrome_options = Options()
        # Additional Chrome options for Replit environment
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--disable-gpu')
        # Set a moderate window size
        chrome_options.add_argument('--window-size=1366,2400')
        chrome_options.add_argument('--hide-scrollbars')  # Hide scrollbars for cleaner screenshots

        # Set the correct Chrome binary location
        chrome_binary = "/nix/store/zi4f80l169xlmivz8vja8wlphq74qqk0-chromium-125.0.6422.141/bin/chromium-browser"
        if not os.path.exists(chrome_binary):
            raise Exception(f"Chrome binary not found at {chrome_binary}")
        chrome_options.binary_location = chrome_binary
        logging.info(f"Using Chrome binary at: {chrome_binary}")

        # Find system chromedriver
        system_chromedriver = subprocess.check_output(["which", "chromedriver"]).decode().strip()
        logging.info(f"Found system ChromeDriver at: {system_chromedriver}")

        # Create a temporary directory for chromedriver if it doesn't exist
        temp_driver_dir = os.path.join(os.getcwd(), "temp_driver")
        if not os.path.exists(temp_driver_dir):
            os.makedirs(temp_driver_dir)
            logging.info(f"Created temporary directory at: {temp_driver_dir}")

        # Copy chromedriver to temporary directory
        temp_driver_path = os.path.join(temp_driver_dir, "chromedriver")
        shutil.copy2(system_chromedriver, temp_driver_path)
        os.chmod(temp_driver_path, 0o755)
        logging.info(f"Copied ChromeDriver to: {temp_driver_path}")

        service = Service(temp_driver_path)
        driver = webdriver.Chrome(service=service, options=chrome_options)
        logging.info("Chrome WebDriver initialized successfully")
        return driver
    except Exception as e:
        logging.error(f"Error setting up Chrome WebDriver: {str(e)}")
        raise

def wait_for_page_load(driver, timeout=30):
    try:
        # Wait for jQuery to load (if present)
        WebDriverWait(driver, timeout).until(
            lambda driver: driver.execute_script('return document.readyState') == 'complete'
        )
        logging.info("Page load complete")
        return True
    except Exception as e:
        logging.error(f"Error waiting for page load: {str(e)}")
        return False

def take_full_screenshot(driver, file_path):
    """Take and crop a full page screenshot."""
    # Get the height of the page
    total_height = get_full_height(driver)
    logging.info(f"Computed page height: {total_height}px")

    # Set window size to accommodate full height but limit to 2400px
    height = min(total_height, 2400)
    width = 1366
    driver.set_window_size(width, height)

    # Wait for any dynamic content to load
    time.sleep(2)  # Increased delay for better rendering

    # Take the screenshot
    driver.save_screenshot(file_path)

    # Open the image for cropping
    try:
        from PIL import Image
        with Image.open(file_path) as img:
            # Crop 10px from each side and 20px from bottom
            crop_box = (
                10,                    # left
                0,                     # top
                width - 10,            # right
                height - 20            # bottom
            )
            cropped_img = img.crop(crop_box)
            cropped_img.save(file_path, quality=95)
            logging.info(f"Saved and cropped screenshot to {file_path}")
    except Exception as e:
        logging.error(f"Error cropping screenshot: {str(e)}")
        # Original screenshot remains if cropping fails


@retry_on_exception(retries=3, delay=2)
def get_result(reg_number, driver):
    try:
        # Navigate to the results page
        logging.info(f"Fetching result for registration number: {reg_number}")
        driver.get("https://results.akuexam.net/MBBS3rdProfP2_2023_A_NEW_Results.aspx")

        # Wait for page to load completely
        if not wait_for_page_load(driver):
            raise Exception("Page failed to load completely")

        # Take screenshot of initial page
        initial_screenshot = f"results/{reg_number}_initial.png"
        take_full_screenshot(driver, initial_screenshot)
        logging.info(f"Saved initial page screenshot to {initial_screenshot}")

        # Try multiple locator strategies for the input field
        input_field = None
        try:
            input_field = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "txtRegNo"))
            )
        except:
            try:
                input_field = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.NAME, "txtRegNo"))
                )
            except:
                input_field = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, "input[type='text']"))
                )

        if not input_field:
            raise Exception("Could not find registration number input field")

        logging.info("Registration number input field found")

        # Clear and enter registration number
        input_field.clear()
        input_field.send_keys(reg_number)
        logging.info(f"Entered registration number: {reg_number}")

        # Take screenshot after entering registration number
        pre_submit_screenshot = f"results/{reg_number}_pre_submit.png"
        take_full_screenshot(driver, pre_submit_screenshot)
        logging.info(f"Saved pre-submit screenshot to {pre_submit_screenshot}")

        # Try to find submit button with multiple strategies
        submit_button = None
        try:
            submit_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.ID, "btnSubmit"))
            )
        except:
            try:
                submit_button = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable((By.NAME, "btnSubmit"))
                )
            except:
                submit_button = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, "input[type='submit']"))
                )

        if not submit_button:
            raise Exception("Could not find submit button")

        # Click submit button
        submit_button.click()
        logging.info("Submit button clicked")

        # Wait for result content to load
        try:
            result_element = WebDriverWait(driver, 20).until(
                EC.presence_of_element_located((By.ID, "pnlResult"))
            )
            logging.info("Result content found")
        except:
            try:
                # Alternative: Look for any table that might contain results
                result_element = WebDriverWait(driver, 20).until(
                    EC.presence_of_element_located((By.TAG_NAME, "table"))
                )
                logging.info("Found result table")
                time.sleep(2) # Added delay here as per intention
            except:
                raise Exception("Could not find result content")

        # Extract student name after finding result table
        student_name = get_student_name(driver)
        if student_name:
            logging.info(f"Extracted student name: {student_name}")
        else:
            logging.warning("Could not extract student name")

        # Take final screenshot
        result_screenshot = f"results/{reg_number}_result.png"
        # Wait a moment for any dynamic content to fully load
        time.sleep(2)
        take_full_screenshot(driver, result_screenshot)
        logging.info(f"Successfully saved result for {reg_number}")

        # Upload result to Telegram with student name in caption
        caption = f"Result for {student_name if student_name else 'Registration Number: ' + reg_number}"
        if upload_to_telegram(result_screenshot, caption):
            # Clean up screenshots after successful upload
            cleanup_file(initial_screenshot)
            cleanup_file(pre_submit_screenshot)
            cleanup_file(result_screenshot)
        else:
            logging.warning(f"Failed to upload result for {reg_number} to Telegram")

        return True
    except Exception as e:
        logging.error(f"Error processing {reg_number}: {str(e)}")
        logging.error(f"Page source at error:\n{driver.page_source}")

        # Take error screenshot
        error_screenshot = f"results/{reg_number}_error.png"
        try:
            take_full_screenshot(driver, error_screenshot)
            logging.info(f"Saved error screenshot to {error_screenshot}")

            # Upload error screenshot to Telegram
            caption = f"Error processing Registration Number: {reg_number}"
            if upload_to_telegram(error_screenshot, caption):
                cleanup_file(error_screenshot)
        except:
            logging.error("Failed to save error screenshot")

        return False

def main():
    # Create results directory if it doesn't exist
    if not os.path.exists("results"):
        os.makedirs("results")
        logging.info("Created results directory")

    # Initialize the driver
    try:
        driver = setup_driver()
        logging.info("WebDriver setup completed")

        # Generate 3 registration numbers for testing
        base_number = 19201209001
        for i in range(3):
            reg_number = str(base_number + i)
            success = get_result(reg_number, driver)
            if success:
                logging.info(f"Successfully processed registration number: {reg_number}")
            else:
                logging.warning(f"Failed to process registration number: {reg_number}")
            time.sleep(2)  # Wait between requests to avoid overwhelming the server

    except Exception as e:
        logging.error(f"Critical error in main execution: {str(e)}")
    finally:
        if 'driver' in locals():
            driver.quit()
            logging.info("WebDriver closed")

if __name__ == "__main__":
    main()