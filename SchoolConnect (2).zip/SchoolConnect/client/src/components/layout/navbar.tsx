import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Link } from "wouter";
import { 
  UserCircle, 
  LogOut, 
  Bell, 
  BookOpen, 
  Calendar,
  Users,
  FileText
} from "lucide-react";

export function Navbar() {
  const { user, logoutMutation } = useAuth();

  const isTeacherOrAdmin = user?.role === 'teacher' || user?.role === 'admin';

  return (
    <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        <div className="mr-4 md:flex">
          <Link href="/" className="mr-6 flex items-center space-x-2">
            <BookOpen className="h-6 w-6 text-primary" />
            <span className="hidden font-bold sm:inline-block">
              School Management System
            </span>
          </Link>
        </div>

        <div className="flex-1 flex items-center justify-between space-x-2">
          <div className="flex items-center space-x-4">
            <Link href="/announcements">
              <Button variant="ghost" className="flex items-center gap-2">
                <Bell className="h-4 w-4" />
                <span>Announcements</span>
              </Button>
            </Link>
            <Link href="/courses">
              <Button variant="ghost" className="flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                <span>Courses</span>
              </Button>
            </Link>
            <Link href="/schedule">
              <Button variant="ghost" className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>Schedule</span>
              </Button>
            </Link>
            {isTeacherOrAdmin && (
              <Link href="/students">
                <Button variant="ghost" className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  <span>Students</span>
                </Button>
              </Link>
            )}
          </div>

          <div className="flex items-center gap-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <UserCircle className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem className="font-medium">
                  {user?.fullName}
                </DropdownMenuItem>
                <DropdownMenuItem className="text-muted-foreground">
                  Role: {user?.role}
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/profile" className="cursor-pointer">
                    <UserCircle className="mr-2 h-4 w-4" />
                    Profile
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => logoutMutation.mutate()}
                  className="text-red-600 cursor-pointer"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </nav>
  );
}