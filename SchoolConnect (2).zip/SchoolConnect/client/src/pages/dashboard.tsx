import { useAuth } from "@/hooks/use-auth";
import { Navbar } from "@/components/layout/navbar";
import { useQuery } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Announcement, Course } from "@shared/schema";
import { Bell, BookOpen, Calendar, Users } from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();

  const { data: courses } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  const { data: announcements } = useQuery<Announcement[]>({
    queryKey: ["/api/announcements"],
  });

  const isTeacherOrAdmin = user?.role === 'teacher' || user?.role === 'admin';

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      <main className="flex-1 container py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900">
            Welcome, {user?.fullName}
          </h1>
          <p className="mt-2 text-gray-600">
            {isTeacherOrAdmin 
              ? "Manage your classes and view student progress"
              : "Track your courses and stay updated with announcements"}
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Courses
              </CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{courses?.length || 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Announcements
              </CardTitle>
              <Bell className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{announcements?.length || 0}</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 md:grid-cols-2 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Announcements</CardTitle>
              <CardDescription>Latest updates and news</CardDescription>
            </CardHeader>
            <CardContent>
              {announcements?.length === 0 ? (
                <p className="text-muted-foreground">No announcements yet</p>
              ) : (
                <div className="space-y-4">
                  {announcements?.map((announcement) => (
                    <div
                      key={announcement.id}
                      className="border-l-4 border-primary pl-4 py-2"
                    >
                      <h3 className="font-medium text-lg">{announcement.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        {announcement.content}
                      </p>
                      <p className="text-xs text-muted-foreground mt-2">
                        {new Date(announcement.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Your Courses</CardTitle>
              <CardDescription>Enrolled courses and classes</CardDescription>
            </CardHeader>
            <CardContent>
              {courses?.length === 0 ? (
                <p className="text-muted-foreground">No courses available</p>
              ) : (
                <div className="space-y-4">
                  {courses?.map((course) => (
                    <div
                      key={course.id}
                      className="flex items-start space-x-4 p-3 hover:bg-muted rounded-lg transition-colors"
                    >
                      <BookOpen className="h-5 w-5 text-primary mt-1" />
                      <div>
                        <h3 className="font-medium">{course.name}</h3>
                        <p className="text-sm text-muted-foreground">
                          {course.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}