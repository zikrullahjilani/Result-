import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  app.get("/api/courses", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const courses = await storage.getCourses();
    res.json(courses);
  });

  app.get("/api/announcements", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const announcements = await storage.getAnnouncements();
    res.json(announcements);
  });

  app.post("/api/announcements", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const announcement = await storage.createAnnouncement({
      ...req.body,
      authorId: req.user!.id,
      createdAt: new Date(),
    });
    res.status(201).json(announcement);
  });

  const httpServer = createServer(app);
  return httpServer;
}
